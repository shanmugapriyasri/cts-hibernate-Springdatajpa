package com.cognizant;

import java.util.List;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
            
      Customer customer1=new Customer("priya","priya@gmail.com","7777788888");
      Customer customer2=new Customer("diya","diya@gmail.com","5555588888");
      Customer customer3=new Customer("sriya","sriya@gmail.com","7777745454");
      Customer customer4=new Customer("riya","riya@gmail.com","7878787878");
 //    CustomerDAO.createRecord(customer1);
  //  CustomerDAO.createRecord(customer2);
  //  CustomerDAO.createRecord(customer3);
   //  CustomerDAO.createRecord(customer4);
      
      System.out.println("\n=======READ RECORDS=======\n");
      List viewCustomers = CustomerDAO.displayRecords();
      if(viewCustomers != null & viewCustomers.size() > 0) {
          for(Object obj : viewCustomers) {
          	Customer empObj=(Customer)obj;
             System.out.println(empObj.toString());
          }
      }

     System.out.println("\n=======UPDATE RECORDS=======\n");
      int updateId = 8;
      CustomerDAO.updateRecord(updateId);
     System.out.println("\n=======READ RECORDS AFTER UPDATION=======\n");
      List updateCustomer = CustomerDAO.displayRecords();
      if(updateCustomer != null & updateCustomer.size() > 0) {
      	for(Object obj : updateCustomer) {
          	Customer empObj=(Customer)obj;
             System.out.println(empObj.toString());
          }
      }

     System.out.println("\n=======DELETE RECORD=======\n");
      int deleteId = 4;
      CustomerDAO.deleteRecord(deleteId);
     System.out.println("\n=======READ RECORDS AFTER DELETION=======\n");
      List deleteCustomerRecord = CustomerDAO.displayRecords();
      for(Object obj : deleteCustomerRecord) {
      	Customer empObj=(Customer)obj;
         System.out.println(empObj.toString());
      }

  /*   System.out.println("\n=======DELETE ALL RECORDS=======\n");
      CustomerDAO.deleteAllRecords();
     System.out.println("\n=======READ RECORDS AFTER ALL RECORDS DELETION=======");
      List deleteAll = CustomerDAO.displayRecords();
      if(deleteAll.size() == 0) {
         System.out.println("\nNo Records Are Present In The Database Table!\n");
      }  */     
    }
}
