package com.cognizant;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;




public class CustomerDAO {

	 static   Session  sessionObj=null;
	 static     Transaction t=null;
	 public static void createRecord(Customer customer) {
	        int count = 0;
	        
	        try {
	            // Getting Session Object From SessionFactory
	           sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	        t= sessionObj.beginTransaction();
	            // Creating Transaction Entities
	              sessionObj.save(customer);
	            // Committing The Transactions To The Database
	              t.commit();
	          
	        } catch(Exception sqlException) {
	            
	   t.rollback();
	          
	        } 
	        sessionObj.close();
	 }
	 
	 
	 public static List displayRecords() {
	        List EmployeesList = new ArrayList();        
	        try {
	            // Getting Session Object From SessionFactory
	        	 sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	        	 t= sessionObj.beginTransaction();

	 
	            EmployeesList = sessionObj.createQuery("FROM Customer").list();
	        } catch(Exception sqlException) {
	           
	             t.rollback();
	           
	        }
	        sessionObj.close();
	        return EmployeesList;
	    }
	 
	    // Method 3: This Method Is Used To Update A Record In The Database Table   
	    public static void updateRecord(int custId) {       
	        try {
	            // Getting Session Object From SessionFactory
	        	 sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	        	 t= sessionObj.beginTransaction();
	 
	            // Creating Transaction Entity
	            Customer c = (Customer) sessionObj.get(Customer.class, custId);
	            sessionObj.evict(c);
	            
	      c.setPhone("99889898989");
	      sessionObj.merge(c);
	            // Committing The Transactions To The Database
	            t.commit();
	         
	        } catch(Exception sqlException) {
	                sessionObj.getTransaction().rollback();
	         
	        }
	        sessionObj.close();
	    }
	 
	    // Method 4(a): This Method Is Used To Delete A Particular Record From The Database Table
	    public static void deleteRecord(Integer custid) {
	        try {
	            // Getting Session Object From SessionFactory
	        	 sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	           t= sessionObj.beginTransaction();
	 
	            Customer c = findRecordById(custid);
	            sessionObj.evict(c);
	            sessionObj.remove(c);
	 
	            // Committing The Transactions To The Database
	            sessionObj.getTransaction().commit();
	           
	        } catch(Exception sqlException) {
	     }
	         sessionObj.close();
	    }
	 
	    // Method 4(b): This Method To Find Particular Record In The Database Table
	    public static Customer findRecordById(Integer custid) {
	        Customer foundCustomer = null;
	        try {
	            // Getting Session Object From SessionFactory
	        	 sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	          t= sessionObj.beginTransaction();
	          foundCustomer = (Customer) sessionObj.load(Customer.class, custid);
	        } catch(Exception sqlException) {
	                sessionObj.getTransaction().rollback();
	         }
	        sessionObj.close();
	        return foundCustomer;
	    }
	 
	    // Method 5: This Method Is Used To Delete All Records From The Database Table
	    public static void deleteAllRecords() {
	        try {
	            // Getting Session Object From SessionFactory
	        sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	            t=sessionObj.beginTransaction();
	            Query queryObj = sessionObj.createQuery("DELETE FROM Customer");
	            queryObj.executeUpdate();
	            // Committing The Transactions To The Database
	            t.commit();
	        } catch(Exception sqlException) {
	               t.rollback();
	            }
	    }
}
