package com.tr;

public class Employee {

	private int eid;
	private String name;
	private String job;
	private String address;
	private double salary;
	private int deptno;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}


	@Override
	public String toString() {
		return "\neid=" + eid + ", name=" + name + ", job=" + job + ", address=" + address + ", salary="
				+ salary + ", deptno=" + deptno;
	}
	
	
	
}
