package com.tr;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	Employee e1 = new Employee();             
         e1.setName("Smith");
        e1.setAddress("Bangalore");
         e1.setJob("Manager");
         e1.setSalary(40000);
         e1.setDeptno(10);
    	EmployeeDAO.createRecord(e1);
    	Employee e2 = new Employee();             
    	e2.setName("King");
    	e2.setAddress("Mangalore");
    	e2.setJob("CEO");
    	e2.setSalary(1000000);
    	e2.setDeptno(20);
   	EmployeeDAO.createRecord(e2);
   	Employee e3 = new Employee();             
   	e3.setName("Allan");
   	e3.setAddress("Chennai");
   	e3.setJob("Accountant");
   	e3.setSalary(45000);
   	e3.setDeptno(30);
	EmployeeDAO.createRecord(e3);
	Employee e4 = new Employee();             
	e4.setName("Jhon");
	e4.setAddress("Bangalore");
	e4.setJob("Developer");
	e4.setSalary(50000);
	e4.setDeptno(10);
	EmployeeDAO.createRecord(e4);
	Employee e5 = new Employee();             
	e5.setName("Joe");
	e5.setAddress("Pune");
	e5.setJob("HR");
	e5.setSalary(43000);
	e5.setDeptno(20);
	EmployeeDAO.createRecord(e5);
    	 
       System.out.println("\n=======READ RECORDS=======\n");
        List viewEmployees = EmployeeDAO.displayRecords();
        if(viewEmployees != null & viewEmployees.size() > 0) {
            for(Object obj : viewEmployees) {
            	Employee empObj=(Employee)obj;
               System.out.println(empObj.toString());
            }
        }
 
       System.out.println("\n=======UPDATE RECORDS=======\n");
        int updateId = 1;
        EmployeeDAO.updateRecord(updateId);
       System.out.println("\n=======READ RECORDS AFTER UPDATION=======\n");
        List updateEmployee = EmployeeDAO.displayRecords();
        if(updateEmployee != null & updateEmployee.size() > 0) {
        	for(Object obj : updateEmployee) {
            	Employee empObj=(Employee)obj;
               System.out.println(empObj.toString());
            }
        }
 
       System.out.println("\n=======DELETE RECORD=======\n");
        int deleteId = 5;
        EmployeeDAO.deleteRecord(deleteId);
       System.out.println("\n=======READ RECORDS AFTER DELETION=======\n");
        List deleteEmployeeRecord = EmployeeDAO.displayRecords();
        for(Object obj : deleteEmployeeRecord) {
        	Employee empObj=(Employee)obj;
           System.out.println(empObj.toString());
        }
 
       System.out.println("\n=======DELETE ALL RECORDS=======\n");
        EmployeeDAO.deleteAllRecords();
       System.out.println("\n=======READ RECORDS AFTER ALL RECORDS DELETION=======");
        List deleteAll = EmployeeDAO.displayRecords();
        if(deleteAll.size() == 0) {
           System.out.println("\nNo Records Are Present In The Database Table!\n");
        }       

}
}