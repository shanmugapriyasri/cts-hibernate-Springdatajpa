package com.tr;

import java.util.ArrayList;
import java.util.List;


import org.hibernate.Session;
import org.hibernate.query.Query;

public class EmployeeDAO {

static	Employee employeeObj = null;
 static   Session  sessionObj=null;
	 public static void createRecord(Employee employeeObj) {
	        int count = 0;
	        
	        try {
	            // Getting Session Object From SessionFactory
	           sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	            sessionObj.beginTransaction();
	             // Creating Transaction Entities
	                sessionObj.save(employeeObj);
   	            // Committing The Transactions To The Database
	            sessionObj.getTransaction().commit();
	          
	        } catch(Exception sqlException) {
	            
	                sessionObj.getTransaction().rollback();
	          
	        } 
	        sessionObj.close();
	 }
	 
	 
	 // Method 2: This Method Is Used To Display The Records From The Database Table
	    @SuppressWarnings("unchecked")
	    public static List displayRecords() {
	        List EmployeesList = new ArrayList();        
	        try {
	            // Getting Session Object From SessionFactory
	        	 sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	            sessionObj.beginTransaction();
	 
	            EmployeesList = sessionObj.createQuery("FROM Employee").list();
	        } catch(Exception sqlException) {
	           
	                sessionObj.getTransaction().rollback();
	           
	        }
	        sessionObj.close();
	        return EmployeesList;
	    }
	 
	    // Method 3: This Method Is Used To Update A Record In The Database Table   
	    public static void updateRecord(int Employee_id) {       
	        try {
	            // Getting Session Object From SessionFactory
	        	 sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	            sessionObj.beginTransaction();
	 
	            // Creating Transaction Entity
	            Employee empObj = (Employee) sessionObj.get(Employee.class, Employee_id);
	         empObj.setSalary(50000);
	            // Committing The Transactions To The Database
	            sessionObj.getTransaction().commit();
	         
	        } catch(Exception sqlException) {
	                sessionObj.getTransaction().rollback();
	         
	        }
	        sessionObj.close();
	    }
	 
	    // Method 4(a): This Method Is Used To Delete A Particular Record From The Database Table
	    public static void deleteRecord(Integer Employee_id) {
	        try {
	            // Getting Session Object From SessionFactory
	        	 sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	            sessionObj.beginTransaction();
	 
	            Employee empObj = findRecordById(Employee_id);
	            sessionObj.delete(empObj);
	 
	            // Committing The Transactions To The Database
	            sessionObj.getTransaction().commit();
	           
	        } catch(Exception sqlException) {
	     }
	         sessionObj.close();
	    }
	 
	    // Method 4(b): This Method To Find Particular Record In The Database Table
	    public static Employee findRecordById(Integer find_Employee_id) {
	        Employee findEmployeeObj = null;
	        try {
	            // Getting Session Object From SessionFactory
	        	 sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	            sessionObj.beginTransaction();
	            findEmployeeObj = (Employee) sessionObj.load(Employee.class, find_Employee_id);
	        } catch(Exception sqlException) {
	                sessionObj.getTransaction().rollback();
	         }
	        sessionObj.close();
	        return findEmployeeObj;
	    }
	 
	    // Method 5: This Method Is Used To Delete All Records From The Database Table
	    public static void deleteAllRecords() {
	        try {
	            // Getting Session Object From SessionFactory
	        sessionObj = HibernateUtil.getSessionFactory().openSession();
	            // Getting Transaction Object From Session Object
	            sessionObj.beginTransaction();
	            Query queryObj = sessionObj.createQuery("DELETE FROM Employee");
	            queryObj.executeUpdate();
	            // Committing The Transactions To The Database
	            sessionObj.getTransaction().commit();
	        } catch(Exception sqlException) {
	                sessionObj.getTransaction().rollback();
	            }
	    }
	        
	 }
