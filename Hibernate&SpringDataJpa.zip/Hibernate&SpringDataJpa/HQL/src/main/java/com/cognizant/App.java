package com.cognizant;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.hibernate.type.DoubleType;

/**
 * Hello world!
 *
 */
public class App {

	public App() {

	}

	public static void main(String[] args) {
		App app = new App();
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		/*
		 * Transaction t=session.beginTransaction(); Product p1=new
		 * Product("toy car","toys",1000.0); Product p2=new
		 * Product("teddy","toys",2000.0); Product p3=new
		 * Product("Redmi","mobile",20000.0); Product p4=new
		 * Product("apple","mobile",40000.0); session.persist(p1); session.save(p2);
		 * session.save(p3); session.save(p4); t.commit();
		 */
		 
		System.out.println("\n************* Display All Records ************");
		display();
		//System.out.println("\n************* Display All Records Name Sorted Order ************");
		//displayOrderByName();
		// insertData();
		// updateData();
		// deleteById();
		// sumPriceNativeQuery();
		 pagination();
	}

	public static void display() {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Query<Product> query = session.createNamedQuery("findAll");
		List<Product> list = query.getResultList();
		for (Product product : list) {
			System.out.println(product);
		}
	}

	public static void displayOrderByName() {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Query<Product> query = session.createNamedQuery("findbyorder");
		List<Product> list = query.getResultList();
		for (Product product : list) {
			System.out.println(product);
		}
	}

	public static void insertData() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		Query insertq1 = session.createQuery(
				"insert into Product  (productId,name,category,price) select p.productId+200, p.name,p.category,p.price from Product p where p.productId=?1");
		insertq1.setParameter(1, 6);
		insertq1.executeUpdate();
		t.commit();
		System.out.println("\n After Insertion ");
		display();
	}

	public static void updateData() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		Query<Product> q1 = session.createQuery("update Product p set p.price=:pricevalue where p.productId=?1",Product.class);
		q1.setParameter("pricevalue", 9999.0);
		q1.setParameter(1, 6);
		q1.executeUpdate();
		t.commit();
		System.out.println("\n After Updation ");
		display();
	}

	public static void deleteById() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		Product p4 = new Product("pen-drive", "electronics", 500.0);
		session.save(p4);
		t.commit();
		System.out.println("After pendrive insertion");
		display();
		t = session.beginTransaction();
		Query q1 = session.createQuery("delete from Product p where p.name=:name");
		q1.setParameter("name", "pen-drive");
		q1.executeUpdate();
		t.commit();
		System.out.println("\n After deletion ");
		display();
	}

	public static void sumPriceNativeQuery() {
		Session session = HibernateUtil.getSessionFactory().openSession();

		List<Object[]> customers = session
				.createNativeQuery("select sum(price) as totalAmount , avg(price) as average from product1")
				.addScalar("totalAmount", new DoubleType()).addScalar("average", new DoubleType()).list();
		for (Object[] objects : customers) {
			double sum = (Double) objects[0];
			double avg = (Double) objects[1];
			System.out.println("sum=" + sum + "\t avg =" + avg);
		}
	}
	
		public static void  pagination() {
			System.out.println("Selected values from 2 nd record upto 3 records");
			Session session = HibernateUtil.getSessionFactory().openSession();
			Query query = session.createQuery("from Product");
			query.setFirstResult(2);
			query.setMaxResults(3);
			List<Product> results = query.list();
			for (Product product : results) {
				System.out.println(product);
			}

		}
	
}
