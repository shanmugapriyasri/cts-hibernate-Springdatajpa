package com.cognizant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="product1")
@NamedQueries({
	@NamedQuery(name="findAll",query="FROM Product"),
	@NamedQuery(name="findbyorder",query="FROM Product order by name")
})
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="prductidgenrator")
	private int productId;
	private String name;
	@Column(name="category_name",length=25)
	private String category;
	private double price;
	
	public Product() {
		// TODO Auto-generated constructor stub
	}

	
	public Product(String name, String category, double price) {
		super();
		this.name = name;
		this.category = category;
		this.price = price;
	}


	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "\nproductId=" + productId + ", name=" + name + ", category=" + category + ", price=" + price;
	}
	
	
	
}
