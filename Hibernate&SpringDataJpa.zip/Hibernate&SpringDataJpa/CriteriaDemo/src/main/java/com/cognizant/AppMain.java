package com.cognizant;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;


public class AppMain {

	@SuppressWarnings({ "deprecation", "unchecked" })
	public static void main(String[] args) {

		Employee emp = new Employee();

		// Creating the config instance & passing the hibernate config file.
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");

		// Session object in hibernate to start the db transaction.
		Session s = config.buildSessionFactory().openSession();

		// Criteria object in hibernate.
		Criteria c1 = s.createCriteria(Employee.class);

		// Restrictions api - Query 1.
		c1.add(Restrictions.eq("designation", "Manager"));

		List<Employee> list1 = c1.list();

		emp.show(list1);

		System.out.println("\n===================\n");

		// Restrictions api - Query 2.
		Criteria c2 = s.createCriteria(Employee.class);

		c2.add(Restrictions.between("id", 3, 5));

		List<Employee> list2 = c2.list();

		emp.show(list2);

		System.out.println("\n===================\n");

		// Restrictions api - Query 3.
		Criteria c3 = s.createCriteria(Employee.class);

		/**** Note: A similar query for 'Restrictions.and(. . . .)' method has to be made !! ****/
		c3.add(Restrictions.or(Restrictions.eq("designation", "VP"), Restrictions.eq("designation", "Software Developer")));

		List<Employee> list3 = c3.list();

		emp.show(list3);

		System.out.println("\n===================\n");

		// Restrictions api - Query 4.
		Criteria c4 = s.createCriteria(Employee.class);

		c4.add(Restrictions.like("name", "A%"));

		List<Employee> list4 = c4.list();

		emp.show(list4);

		// Closing the session object.
		s.close();
	}
}