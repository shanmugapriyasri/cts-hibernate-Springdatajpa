package com.tr;

import java.util.List;


import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;


import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestCriteria {

	public static void main(String[] args) {
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");

		// Session object in hibernate to start the db transaction.
		Session s = config.buildSessionFactory().openSession();
Transaction tr=s.beginTransaction();
		
		
		  Employee e1=new Employee("priya", "Bangalore", 12345,1002); 
		  Employee e2=new
		  Employee("riya", "Mangalore", 1235656,1500); 
		  Employee e3=new Employee("diya",
		  "Bangalore", 12342312,2000);
		  Employee e4=new Employee("sri", "Mangalore",
		  123454675,800);
		  Employee e5=new Employee("sriya", "Mysore", 12348765,900);
		  s.save(e1); s.save(e2); s.save(e3); s.save(e4); s.save(e5);
		 
		 

		CriteriaBuilder cb = s.getCriteriaBuilder();
		CriteriaQuery<Employee> cq = cb.createQuery(Employee.class);
		Root<Employee> root = cq.from(Employee.class);
		cq.select(root);
		TypedQuery<Employee> tq = s.createQuery(cq);
		List<Employee> elist = tq.getResultList();
		display(elist);

		
		  System.out.println("Order by name"); 
		  cq = (CriteriaQuery<Employee>)   cq.orderBy(cb.asc(root.get("name")));
		  tq = s.createQuery(cq); 
		  elist = tq.getResultList();
		  display(elist);
		 	
		  
		  System.out.println("Display Name and Address only");
		  
		  CriteriaQuery<Object> cq1 = cb.createQuery(Object.class);
		  Root<Employee> root1=cq1.from(Employee.class);
		  CriteriaQuery<Object> q1 = cq1.select(root1);
		  q1.multiselect(root1.get("name"),root1.get("address"));
		   Query query = s.createQuery(q1);
		   List<Object[]> result = query.getResultList();
	      
		   for (Object[] values : result) {
			  String name = (String) values[0];
			  String address = (String) values[1];
			    System.out.println(name+"\t"+address);
			}
		
		tr.commit();
	}

	static void display(List<Employee> list) {
		for (Employee e : list) {
			System.out.println(e);
		}
	}
}
