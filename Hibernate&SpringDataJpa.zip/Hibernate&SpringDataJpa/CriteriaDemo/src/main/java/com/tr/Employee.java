package com.tr;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="emp10")
public class Employee {

	@Id
	@GeneratedValue
	public int id;
	@Column(nullable=false,length=25)
	 String name;
	@Column
	 String address;
	@Column(unique=true)
	 long phone;
	@Column
public	 double salary;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	public Employee(String name, String address) {
		super();
		this.name = name;
		this.address = address;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Employee(String name, String address, long phone, double salary) {
		super();
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return  id + "\t" + name + "\t" + address
				+ "\t" + phone + "\t" + salary ;
	}
	
	
	
}