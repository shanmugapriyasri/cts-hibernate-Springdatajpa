package com.cognizant;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.model.Person;
import com.cognizant.service.PersonNotFoundException;
import com.cognizant.service.PersonService;

@SpringBootApplication
public class FirstSpringDataJpaApplication {

	private static PersonService personService;
	private static final Logger LOGGER = LoggerFactory.getLogger(FirstSpringDataJpaApplication.class);

	private static void testGetAllPersions() {
		LOGGER.info("Start");
		List<Person> persons = personService.getAllPersons();
		LOGGER.debug("persons={}", persons);
		LOGGER.info("End");
	}

	private static void getAllpersonsTest() throws PersonNotFoundException {

		LOGGER.info("Start");
		Person person = personService.findPersonById(1);
		LOGGER.debug("Person:{}", person);
		LOGGER.info("End");
	}

	private static void testAddPerson() throws PersonNotFoundException {
		LOGGER.info("Start");
		Person person = new Person();
		person.setName("Smith");
		person.setAddress("Bangalore");
		personService.addPerson(person);
		person = personService.findPersonById(1);
		LOGGER.debug("Person:{}", person);
		LOGGER.info("End");	
	}
	private static void testUpdatePerson() throws PersonNotFoundException {
		LOGGER.info("Start");
		personService.updatePerson(1, "Smith","Pune");
		Person Person = personService.findPersonById(1);
		LOGGER.debug("Person:{}", Person);
		LOGGER.info("End");		
	}
	private static void testDeletePerson() throws PersonNotFoundException{
		LOGGER.info("Start");
		testAddPerson();
		personService.deletePerson(2);
		Person Person = personService.findPersonById(2);
		LOGGER.debug("Person:{}", Person);
		LOGGER.info("End");		
	}

	

	
	
	public static void main(String[] args) {
		ApplicationContext context=	SpringApplication.run(FirstSpringDataJpaApplication.class, args);
		personService = context.getBean(PersonService.class);
		
		try {
			testAddPerson();
			testUpdatePerson();
			getAllpersonsTest();
		
		//	testDeletePerson();
		} catch (PersonNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		testGetAllPersions();
		LOGGER.info("Inside main");
	}

}
