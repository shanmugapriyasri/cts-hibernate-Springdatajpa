package com.cognizant.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.Person;
import com.cognizant.repository.PersonRepository;


@Service
public class PersonService {
	@Autowired
	PersonRepository personRepository;

//	@Transactional
	public List<Person> getAllPersons() {
		return personRepository.findAll();
	}
//	@Transactional
	public Person findPersonById(int personId) throws PersonNotFoundException{
		Optional<Person> result = personRepository.findById(personId);
		if (!result.isPresent()) {
			throw new PersonNotFoundException("Not Found"+personId+"");
		}
		return result.get();
	}
	@Transactional
	public void addPerson(Person person) {
		personRepository.save(person);
	}
	@Transactional
	public void updatePerson(int i, String name,String address) throws PersonNotFoundException {
		Person person = personRepository.findById(i).get();
		if(person==null) {
			throw new PersonNotFoundException("Not Found"+i+"");
		}
		person.setName(name);
		person.setAddress(address);
		personRepository.save(person);
	}
	@Transactional
	public void deletePerson(int personId) {
		personRepository.deleteById(personId);
	}
}
