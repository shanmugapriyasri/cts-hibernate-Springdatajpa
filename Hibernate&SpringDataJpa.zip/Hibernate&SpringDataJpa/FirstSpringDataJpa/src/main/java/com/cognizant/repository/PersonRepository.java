package com.cognizant.repository;

import org.springframework.stereotype.Repository;

import com.cognizant.model.Person;

import org.springframework.data.jpa.repository.JpaRepository;
@Repository
public interface PersonRepository extends JpaRepository<Person, Integer> {
}
