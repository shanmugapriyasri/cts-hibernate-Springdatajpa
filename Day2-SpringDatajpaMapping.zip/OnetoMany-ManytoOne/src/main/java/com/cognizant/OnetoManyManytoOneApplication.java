package com.cognizant;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.bean.Department;
import com.cognizant.bean.Employee;
import com.cognizant.service.DepartmentService;
import com.cognizant.service.EmployeeService;

@SpringBootApplication
public class OnetoManyManytoOneApplication {
	public static EmployeeService employeeService;
	public static DepartmentService departmentService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OnetoManyManytoOneApplication.class);

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(OnetoManyManytoOneApplication.class, args);
		employeeService=context.getBean(EmployeeService.class);
		departmentService=context.getBean(DepartmentService.class);
	
		//testAddOneDeptManyEmp();
	testAddManyEmptoOneDept();
	//	testAddEmployee();
	//	testGetEmployee();
	//	testUpdateEmployee();
		testGetDepartment();
	}

	public static void testGetEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(1);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.debug("Department:{}", employee.getDepartment());
		
		LOGGER.info("End");
	}

	
	public static void testAddOneDeptManyEmp() {
		Employee e1=new Employee("A",2000.0,true, new Date(2012-02-02));
		Employee e2=new Employee("B",3000.0,false, new Date(2015-03-03));
	
		Set<Employee> empset=new HashSet<>();
		empset.add(e1);
		empset.add(e2);
		Department d1=new Department("Development",empset);
		e1.setDepartment(d1);
		e2.setDepartment(d1);
		departmentService.save(d1);
		}
	
	
		public static void testAddManyEmptoOneDept() {
			Department d1=new Department();
			d1.setName("Accounts");
			departmentService.save(d1);
		Employee e1=new Employee("ZA",2000.0,true, new Date(2018-12-20));
		Employee e2=new Employee("ZB",3000.0,false, new Date(2018-11-20));
		e1.setDepartment(d1);
		e2.setDepartment(d1);
		employeeService.save(e1);
		employeeService.save(e2);
		}
	
	
	public static void testAddEmployee() {
		LOGGER.info("Start");
		Employee employee = new Employee();
		employee.setName("Raka");
		employee.setSalary(50000);
		employee.setPermanent(true);
		employee.setDate_of_birth(Date.valueOf("1995-02-21"));
		Department department = departmentService.get(1);
		employee.setDepartment(department);
		employeeService.save(employee);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.info("End");
	}

	public static void testUpdateEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(2);
		Department department = departmentService.get(1);
		employee.setDepartment(department);
		employee.setName("newname");
		employeeService.save(employee);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.info("End");
	}

	public static void testGetDepartment() {
		LOGGER.info("Start");
		Department department = departmentService.get(1);
		LOGGER.debug("Department:{}", department);
		Set<Employee> employees = department.getEmployeeList();
		LOGGER.debug("Employee List:{}", employees);
		LOGGER.info("End");
	}

}
