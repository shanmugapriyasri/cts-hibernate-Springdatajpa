package com.cognizant.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.beans.Address;
import com.cognizant.beans.Student;
import com.cognizant.repository.StudentRepository;
@Service
public class StudentService {


	@Autowired
public StudentRepository studentRepository;
	
	@Transactional
	 public void addStudent() {
	Address address=new Address("#88,88th,Naga88r","bangalore",888888);
	Student student=new Student();
	student.setName("priya888");
	student.setAddress(address);
studentRepository.save(student);
}


	 public void displayAllStudents() {
	List<Student> list=studentRepository.findAll();
	for (Student student : list) {
		System.out.println(student);
	}
}

		@Transactional
	 public void deletebyId() {
	Address address=new Address("#27,8thcross,S.R.Nagar","Mangalore",560025);
	Student student=new Student();
	student.setName("riya");
	student.setAddress(address);
	studentRepository.save(student);
	int id=student.getStudId();
	System.out.println("******New student:"+studentRepository.getOne(id));
	studentRepository.delete(student);
	System.out.println("******New student after delete:"+studentRepository.getOne(id));
	
}

		@Transactional
	 public void update() {
	
	Address address=new Address("#27,18thcross,S.R.Nagar","pune",560025);
	Student student=new Student();
	student.setName("diya");
	student.setAddress(address);
	studentRepository.save(student);
	int id=student.getStudId();
	Student newstudent=studentRepository.getOne(id);
	System.out.println("******New student:"+newstudent);
	newstudent.setName("Sridiya");
	studentRepository.save(newstudent);
	System.out.println("******New student after update:"+studentRepository.getOne(id));
	
}
}
