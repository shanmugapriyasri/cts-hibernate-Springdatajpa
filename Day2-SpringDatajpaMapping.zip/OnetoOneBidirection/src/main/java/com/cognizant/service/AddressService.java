package com.cognizant.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.beans.Address;
import com.cognizant.beans.Student;
import com.cognizant.repository.AddressRepository;
import com.cognizant.repository.StudentRepository;
@Service
public class AddressService {

	@Autowired
public StudentRepository studentRepository;
	

	@Autowired
public AddressRepository addressRepository;
	@Transactional
	 public void addAddress() {
		Student student=new Student();
		student.setName("Mr.ABC");
		
	Address address=new Address("#96,MGRoad","Chennai",444444);
	student.setAddress(address);
	address.setStudent(student);
	
	addressRepository.save(address);
}


	 public void displayAllAddress() {
	List<Address> list=addressRepository.findAll();
	for (Address address : list) {
		System.out.println(address +"Student details"+address.getStudent().getStudId()+"\t"+address.getStudent().getName());
	}
}
}
