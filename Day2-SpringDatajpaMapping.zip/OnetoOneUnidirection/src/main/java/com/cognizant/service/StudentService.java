package com.cognizant.service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.beans.Address;
import com.cognizant.beans.Student;
import com.cognizant.repository.StudentRepository;
@Service
public class StudentService {

	Logger LOGGER=LoggerFactory.getLogger(StudentService.class);

	@Autowired
public StudentRepository studentRepository;
	
	@Transactional
	 public void addStudent() {
		LOGGER.info("start");
	Address address=new Address("#27,8thcross,S.R.Nagar","bangalore",560025);
	Student student=new Student();
	student.setName("priya");
	student.setAddress(address);
studentRepository.save(student);
		LOGGER.info(student.getStudId()+" persisted");
		LOGGER.info("end");
}


	 public void displayAllStudents() {
	List<Student> list=studentRepository.findAll();
	for (Student student : list) {
		System.out.println(student);
	}
}

		@Transactional
	 public void deletebyId() throws StudentNotFoundException {
	Address address=new Address("#27,8thcross,S.R.Nagar","Mangalore",560025);
	Student student=new Student();
	student.setName("riya");
	student.setAddress(address);
	studentRepository.save(student);
	int id=student.getStudId();
	System.out.println("******New student:"+studentRepository.getOne(id));
	studentRepository.delete(student);
	if(studentRepository.getOne(id)==null) {
		throw new StudentNotFoundException("Student id not there");
	}
	
}

		@Transactional
	 public void update() {
	
	Address address=new Address("#27,18thcross,S.R.Nagar","pune",560025);
	Student student=new Student();
	student.setName("diya");
	student.setAddress(address);
	studentRepository.save(student);
	int id=student.getStudId();
	Student newstudent=studentRepository.getOne(id);
	System.out.println("******New student:"+newstudent);
	newstudent.setName("Sridiya");
	studentRepository.save(newstudent);
	System.out.println("******New student after update:"+studentRepository.getOne(id));
	
}
}
