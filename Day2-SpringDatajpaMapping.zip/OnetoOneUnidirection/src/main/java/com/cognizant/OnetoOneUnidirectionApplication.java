package com.cognizant;

import java.util.List;

import javax.transaction.Transactional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.beans.Address;
import com.cognizant.beans.Student;
import com.cognizant.repository.StudentRepository;
import com.cognizant.service.StudentService;



	
	@SpringBootApplication
	@ComponentScan("com.*")
	public class OnetoOneUnidirectionApplication {


		public static void main(String[] args) {
ApplicationContext context=	SpringApplication.run(OnetoOneUnidirectionApplication.class, args);
			StudentService service=(StudentService)context.getBean("studentService");
			StudentService studentService=context.getBean(StudentService.class);
		//	service.addStudent();
			service.displayAllStudents();
//service.update();
try {
	service.deletebyId();
} catch (Exception e) {
	// TODO Auto-generated catch block
	System.out.println("Main :"+e);
}
	}

}
