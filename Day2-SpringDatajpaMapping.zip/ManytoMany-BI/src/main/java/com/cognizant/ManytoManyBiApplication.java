package com.cognizant;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.bean.Order;
import com.cognizant.bean.Product;
import com.cognizant.service.OrderService;
import com.cognizant.service.ProductService;

@SpringBootApplication
public class ManytoManyBiApplication {
static	ProductService productService=null;
static	OrderService orderService=null;
	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(ManytoManyBiApplication.class, args);
		 productService=context.getBean(ProductService.class);
		 orderService=context.getBean(OrderService.class);
		//testAddProduct();
		makeOrder();
		
	}
	
static	public void testAddProduct() {
		Product p1=new Product();
		p1.setName("mobile");
		p1.setPrice(20000);
		
		Product p2=new Product();
		p2.setName("tv");
		p2.setPrice(40000);
		
		Product p3=new Product();
		p3.setName("lipstick");
		p3.setPrice(2000);
		
		Product p4=new Product();
		p4.setName("pen");
		p4.setPrice(200);
		
		productService.save(p1);
		productService.save(p2);
		productService.save(p3);
		productService.save(p4);
	}


static public void makeOrder() {
	Order order1=new Order();
	order1.setOrderDate(new Date());
	order1.addProduct(productService.get(1));
	order1.addProduct(productService.get(2));
	order1.addProduct(productService.get(3));
	orderService.save(order1);
	}
}
