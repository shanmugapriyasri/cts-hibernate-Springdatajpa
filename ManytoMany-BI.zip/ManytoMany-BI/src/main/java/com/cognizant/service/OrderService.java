package com.cognizant.service;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.bean.Order;
import com.cognizant.repository.OrderRepository;

@Service
public class OrderService {
	@Autowired
	OrderRepository orderRepository;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OrderService.class);
	
	public Order get(int id) {
		LOGGER.info("Start");
		return orderRepository.findById(id).get();
	}

	@Transactional
	public void save(Order order) {
		LOGGER.info("Start");
		orderRepository.save(order);
		LOGGER.info("End");
	}
}
