package com.cognizant.service;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.bean.Product;
import com.cognizant.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository productRepository;
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductService.class);

	
	public Product get(int id) {
		LOGGER.info("Start");
		return productRepository.findById(id).get();
	}

	@Transactional
	public void save(Product product) {
		LOGGER.info("Start");
	productRepository.save(product);
		LOGGER.info("End");
	}
}
