package com.cognizant;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.bean.Order;
import com.cognizant.bean.Product;
import com.cognizant.service.OrderService;
import com.cognizant.service.ProductService;

@SpringBootApplication
public class ManytoManyBiApplication {
static	ProductService productService=null;
static	OrderService orderService=null;
	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(ManytoManyBiApplication.class, args);
		 productService=context.getBean(ProductService.class);
		 orderService=context.getBean(OrderService.class);
		 testAddProductOrder();
		
	}

static	public void testAddProductOrder() {
		Product p1=new Product();
		p1.setName("mobile");
		p1.setPrice(20000);
		
		Product p2=new Product();
		p2.setName("tv");
		p2.setPrice(40000);
		
		Product p3=new Product();
		p3.setName("lipstick");
		p3.setPrice(2000);
		
		Product p4=new Product();
		p4.setName("pen");
		p4.setPrice(200);
		
	Order order1=new Order();
	order1.setOrderDate(new Date());
	order1.addProduct(p1);
	order1.addProduct(p2);
	order1.addProduct(p4);
	orderService.save(order1);
	
	System.out.println("Order successful!...");
		
	}
}
